from flask_apscheduler import APScheduler
from apps.ctr import filtering_handle

scheduler = APScheduler()


@scheduler.task('interval', id='refresh', days=1, misfire_grace_time=900)
def refresh():
    filtering_handle.refresh()


