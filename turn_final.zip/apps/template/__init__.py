from flask import Flask
from apps.template.models import db
from apps.scheduler import scheduler
from apps.ctr import filtering_handle


def create_app():
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:123456@1.12.66.67:3307/rollup"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True
    app.config["SECRET_KEY"] = "BaiguiSB"
    app.config["EXPIRATION"] = 3600
    app.config["FILE_PATH"] = app.config.root_path[:-14] + "static\\"
    app.config["CTR_BACKEND"] = "Collaborative Filtering"

    db.init_app(app)
    if app.config["CTR_BACKEND"] == "Collaborative Filtering":
        filtering_handle.init_app(app)
        filtering_handle.refresh()
        scheduler.init_app(app)
        scheduler.start()
    elif app.config["CTR_BACKEND"] == "PNN":
        pass

    return app
