from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Posts(db.Model):
    __tablename__ = "posts"
    id = db.Column(db.BIGINT, primary_key=True, nullable=False)
    title = db.Column(db.VARCHAR(255), nullable=False)
    content = db.Column(db.TEXT)
    user_id = db.Column(db.BIGINT)
    discuss_num = db.Column(db.Integer)
    is_deleted = db.Column(db.Integer)
    gmt_created = db.Column(db.DateTime)
    gmt_modified = db.Column(db.DateTime)


class History(db.Model):
    __tablename__ = "history"
    id = db.Column(db.BIGINT, primary_key=True, nullable=False)
    user_id = db.Column(db.BIGINT)
    target_id = db.Column(db.BIGINT)
    sort = db.Column(db.BIGINT)
    is_deleted = db.Column(db.BIGINT)
    gmt_created = db.Column(db.DateTime)
    gmt_modified = db.Column(db.DateTime)


class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.BIGINT, primary_key=True, nullable=False)
    email = db.Column(db.VARCHAR(50))
    password = db.Column(db.VARCHAR(500))
    role = db.Column(db.VARCHAR(30))
    is_deleted = db.Column(db.BIGINT)
    gmt_created = db.Column(db.DateTime)
    gmt_modified = db.Column(db.DateTime)
