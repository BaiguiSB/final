from keras.models import *
from keras.layers import *
from os.path import exists
import pickle
from apps.template.models import History, Posts
import numpy as np
import datetime


def ipnn(feature):
    import tensorflow as tf
    field_num = feature.shape[1]
    row, col = [], []
    for i in range(field_num - 1):
        for j in range(i + 1, field_num):
            row.append(i)
            col.append(j)
    p = tf.transpose(tf.gather(tf.transpose(feature, [1, 0, 2]), row), [1, 0, 2])  # [None, pair_num, k]
    q = tf.transpose(tf.gather(tf.transpose(feature, [1, 0, 2]), col), [1, 0, 2])  # [None, pair_num, k]
    InnerProduct = tf.reduce_sum(p * q, axis=-1)  # [None, pair_num]
    return InnerProduct


def build_model(predict_feature_input_num=11):
    input_predict_features = list()

    for i in range(predict_feature_input_num):
        input_predict_features.append(Input(shape=(20, 300), dtype="float"))
    predict_features = input_predict_features[:]

    embedding_layer1 = LSTM(30, activation="relu", use_bias=True, return_sequences=True)
    embedding_layer2 = LSTM(30, activation="relu", use_bias=True)
    for i in range(predict_feature_input_num):
        predict_features[i] = embedding_layer1(predict_features[i])
        predict_features[i] = embedding_layer2(predict_features[i])
        predict_features[i] = Reshape((1, 100))(predict_features[i])

    feature = Concatenate(axis=1)(predict_features)
    ipnn_feature = Lambda(ipnn)(feature)
    feature = Reshape((feature.shape[1] * feature.shape[2],))(feature)
    feature = Concatenate(axis=1)([ipnn_feature, feature])
    feature = BatchNormalization()(feature)
    feature = Dense(50, activation="relu", use_bias=True)(feature)
    feature = BatchNormalization()(feature)
    res = Dense(1, activation="sigmoid", use_bias=True)(feature)
    model = Model(inputs=input_predict_features, outputs=res)
    model.compile(optimizer="Adadelta", loss='mean_squared_logarithmic_error', metrics=['mean_absolute_error'])
    return model


class Embedding_Word:
    word_vector = dict()
    keys = list()

    def __init__(self):
        with open("word/sgns.zhihu.word/sgns.zhihu.word.pkl", "rb") as f:
            self.word_vector = pickle.load(f)
        with open("word/sgns.zhihu.word/sgns.zhihu.word.dict.pkl", "rb") as f:
            self.keys = pickle.load(f)

    def emb_fy(self, s: str):
        vectors = list()
        lens = s.__len__()
        index = 0

        max_step = lens if lens < 8 else 8
        step = max_step
        compare_fail = False
        while index < lens:
            if s[index:index + step] in self.keys:
                if compare_fail:
                    compare_fail = False
                    vectors.append(np.array([0.0] * 300))
                vectors.append(self.word_vector[s[index:index + step]])
                index += step
                step = max_step
                if index + step > lens:
                    step = lens - index
            elif step > 1:
                step -= 1
            elif step == 1:
                compare_fail = True
                index += step
                step = max_step
                if index + step > lens:
                    step = lens - index
        if vectors.__len__() > 21:
            vectors = vectors[:21]
        elif vectors.__len__() < 21:
            for _ in range(21 - vectors.__len__()):
                vectors.append([0.0] * 300)
        return vectors


class PNN_Net:
    app = None
    pnn_model = None

    def init_app(self, app):
        self.app = app
        if app.config["CTR_BACKEND"] == "PNN":
            if exists("pnn_model.pkl"):
                with open("pnn_model.pkl", "rw") as f:
                    self.pnn_model = pickle.load(f)

    def predict(self, user_id, res_len=10):
        user_id = int(user_id)
        history = list()
        emb = Embedding_Word()

        for item in History.query.filtter(History.user_id == user_id).order_by(History.gmt_created.desc()).all():
            history.append(item.target_id)

        posts = Posts.query.order_by(History.gmt_created.desc()).limit(100).all()
        features = list()
        features.append([])
        for i in range(posts.__len__()):
            features[0].append(np.array(emb.emb_fy(posts[i].title)))

        for i in range(history.__len__()):
            s = Posts.query.filtter_by(id=history[i]).first().content
            features.append(np.array([emb.emb_fy(s)] * posts.__len__()))
            if i >= 10:
                break

        res = self.pnn_model.predict(features)
        res = res.reshape((res.shape[1],))
        res_index = res.argsort()[::-1][0:res_len]
        for i in range(res_index.__len__()):
            res[i] = posts[res_index[i]].id
        return res

    # (11,100,21,300)
