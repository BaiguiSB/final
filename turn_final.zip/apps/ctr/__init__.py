from apps.ctr.Filtering import Collaborative_Filtering

filtering_handle = Collaborative_Filtering(10)
