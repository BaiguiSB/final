import random
import numpy as np
from apps.template.models import History, Posts, User


class Collaborative_Filtering:
    posts_id_map_forward = dict()
    posts_id_map_backward = list()
    user_id_map_forward = dict()
    user_id_map_backward = list()
    recent_list = list()
    filter_matrix = None
    max_user = int()
    app = None

    def __init__(self, max_user=10):
        self.max_user = max_user

    def predict(self, user_id, res_len):
        user_num = self.filter_matrix.shape[0]
        post_num = self.filter_matrix.shape[1]

        sim_list = list()
        user_id = self.user_id_map_forward[user_id]
        user_std = self.filter_matrix[user_id].std()

        if user_std == 0:
            return self.zero_vector(res_len)

        for i in range(user_num):
            if self.filter_matrix[i].std() == 0.0:
                sim_list.append(0.0)
            else:
                sim_list.append(
                    np.cov(self.filter_matrix[[i, user_id], :])[0][1] / (user_std * self.filter_matrix[i].std()))
        sim_list[user_id] = 0
        sim_list_index = np.array(sim_list).argsort()[::-1][0:self.max_user]

        score_list = list()
        for i in range(post_num):
            score_list.append(0.0)
            for similar_user_index in sim_list_index:
                score_list[i] += sim_list[similar_user_index] * self.filter_matrix[similar_user_index][i]
        score_list = np.array(score_list)
        score_list_index = np.array(score_list).argsort()[::-1][0:res_len]
        res = list()
        for i in score_list_index:
            res.append(self.posts_id_map_backward[i])
        return res

    def refresh(self):
        with self.app.app_context():
            index = 0
            temp_list1 = list()
            temp_dict1 = dict()
            for item in Posts().query.all():
                temp_dict1[str(item.id)] = index
                temp_list1.append(item.id)
                index += 1

            index = 0
            temp_list2 = list()
            temp_dict2 = dict()
            for item in User().query.all():
                temp_dict2[str(item.id)] = index
                temp_list2.append(item.id)
                index += 1

            temp_matrix = np.array([[0] * temp_list1.__len__()] * temp_list2.__len__())
            temp_recent_list = list()
            his_all = History.query.all()
            his_all.reverse()
            for his in his_all:
                if his.sort == 1:
                    temp_matrix[temp_dict2[str(his.user_id)]][temp_dict1[str(his.target_id)]] += 1.0
                    if str(his.target_id) not in temp_recent_list:
                        temp_recent_list.append(str(his.target_id))
            self.filter_matrix = temp_matrix.copy()
            self.user_id_map_forward = temp_dict2.copy()
            self.user_id_map_backward = temp_list2.copy()
            self.posts_id_map_forward = temp_dict1.copy()
            self.posts_id_map_backward = temp_list1.copy()
            self.recent_list = temp_recent_list.copy()

    def zero_vector(self, res_len):
        if res_len >= self.recent_list.__len__():
            return self.recent_list
        elif res_len * 3 >= self.recent_list.__len__():
            return random.sample(self.recent_list, res_len)
        else:
            return random.sample(self.recent_list[:res_len * 3], res_len)

    def init_app(self, app):
        self.app = app
