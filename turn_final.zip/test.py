import numpy as np

filter_matrix = np.array([[1, 0, 0, 1, 1, 0, 0, 1, 1],
                          [1, 2, 1, 0, 0, 0, 1, 1, 0],
                          [1, 2, 1, 0, 1, 1, 1, 1, 0]])


def predict(user_id):
    user_num = filter_matrix.shape[0]
    post_num = filter_matrix.shape[1]

    sim_list = list()
    user_std = filter_matrix[user_id].std()
    for i in range(user_num):
        sim_list.append(
            np.cov(filter_matrix[[i, user_id], :])[0][1] / (user_std * filter_matrix[i].std()))
    sim_list[user_id] = 0
    sim_list_index = np.array(sim_list).argsort()[::-1][0:2]

    score_list = list()
    for i in range(post_num):
        score_list.append(0.0)
        for similar_user_index in sim_list_index:
            score_list[i] += sim_list[similar_user_index] * filter_matrix[similar_user_index][i]


def main():
    predict(2)


if __name__ == '__main__':
    main()
